// src/hooks/useWalletConnect.js
// Safe wrapper around WalletProvider (no WalletConnect init here)

import { useWallet } from "../context/WalletProvider";

export default function useWalletConnect() {
  return useWallet();
}
