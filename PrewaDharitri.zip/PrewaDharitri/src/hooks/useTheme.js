// src/hooks/useTheme.js
import AsyncStorage from '@react-native-async-storage/async-storage';
import { createContext, useContext, useEffect, useState } from 'react';
import { Appearance } from 'react-native';
import { dark, light } from '../constants/theme';

const STORAGE_KEY = 'USER_THEME_PREF';
const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const colorScheme = Appearance.getColorScheme(); // 'dark'|'light'|null
  const [themeName, setThemeName] = useState(null); // 'light'|'dark'|null

  useEffect(() => {
    (async () => {
      try {
        const saved = await AsyncStorage.getItem(STORAGE_KEY);
        if (saved === 'light' || saved === 'dark') setThemeName(saved);
        else setThemeName(null);
      } catch (e) {
        setThemeName(null);
      }
    })();
  }, []);

  const resolvedThemeName = themeName ?? colorScheme ?? 'light';
  const theme = resolvedThemeName === 'dark' ? dark : light;

  const setPreference = async (pref) => {
    try {
      if (pref === null) await AsyncStorage.removeItem(STORAGE_KEY);
      else await AsyncStorage.setItem(STORAGE_KEY, pref);
      setThemeName(pref);
    } catch (e) {
      console.warn('Failed to save theme preference', e);
    }
  };

  return (
    <ThemeContext.Provider value={{ theme, themeName, resolvedThemeName, setPreference }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);
