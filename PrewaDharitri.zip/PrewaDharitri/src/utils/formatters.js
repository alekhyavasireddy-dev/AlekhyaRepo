// src/utils/formatters.js
export const shortAddress = (addr = '') => {
  if (!addr) return '';
  return addr.slice(0, 6) + '...' + addr.slice(-4);
};

export const formatBalance = (value, decimals = 18) => {
  try {
    const bn = BigInt(value.toString());
    // naive formatting — replace with ethers.utils.formatUnits in real code
    return (Number(bn) / Math.pow(10, decimals)).toFixed(4);
  } catch (e) {
    return '0';
  }
};
