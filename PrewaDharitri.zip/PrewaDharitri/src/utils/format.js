// utils/format.js
export const formatTokenAmount = (valueStr, decimals = 18, maxDigits = 6) => {
  if (!valueStr) return "-";
  // valueStr is formatted like "12345.6789"
  const num = Number(valueStr);
  if (Number.isNaN(num)) return "-";
  if (num < 0.000001) return Number(num).toExponential(2);
  return num.toLocaleString(undefined, { maximumFractionDigits: maxDigits });
};
