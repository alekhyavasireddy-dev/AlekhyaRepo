// constants/token.js
export const PREWA_TOKEN_ADDRESS = "0x0440b0893167f66e49a82eF6F3b4c2Aed7fe10Bf";

// Minimal ERC20 ABI we need
export const ERC20_MIN_ABI = [
  // name, symbol, decimals, balanceOf
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function balanceOf(address) view returns (uint256)",
];
