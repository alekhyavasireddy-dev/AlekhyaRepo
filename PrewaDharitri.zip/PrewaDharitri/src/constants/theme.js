// src/constants/theme.js
export const light = {
  mode: 'light',
  background: '#FFFFFF',
  surface: '#F7F7F8',
  text: '#0B0B0B',
  subtext: '#666666',
  primary: '#000000',
  card: '#FFFFFF',
  border: '#E6E6E6',
  accent: '#00A86B',
};

export const dark = {
  mode: 'dark',
  background: '#0B0B0D',
  surface: '#121215',
  text: '#FFFFFF',
  subtext: '#BFC3C8',
  primary: '#FFFFFF', // buttons use dark bg or adapt as needed
  card: '#0F1113',
  border: '#1F1F1F',
  accent: '#00D084',
};
