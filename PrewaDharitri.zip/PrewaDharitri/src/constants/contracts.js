// src/constants/contracts.js
export const NETWORK = {
  chainId: 56, // example: BSC Mainnet; replace with testnet if needed
  name: 'BNB Smart Chain',
};

// put actual addresses from the GitHub repo here:
export const CONTRACTS = {
  pREWA: {
    address: '0x0440b...7fe10Bf', // replace
    abi: [ /* replace with token ABI */ ],
  },
  Staking: {
    address: '0x...', // replace
    abi: [ /* replace with staking ABI */ ],
  },
  // add swap router, pools contract etc.
};
