
export const USDT_TOKEN = "0x7f5c764cbc14f9669b88837ca1490cca17c31607";
export const PREWA_TOKEN = "0x0440b0893167f66e49a82ef6f3b4c2aed7fe10bf";
export const PANCAKE_ROUTER_TESTNET = "0xd99d1c33f9fc3444f8101754abc46c52416550d1";





export const ERC20_ABI_MIN = [
  "function name() view returns (string)",
  "function symbol() view returns (string)",
  "function decimals() view returns (uint8)",
  "function balanceOf(address) view returns (uint256)",
  "function allowance(address owner, address spender) view returns (uint256)",
  "function approve(address spender, uint256 amount) returns (bool)",
];

export const ROUTER_V2_ABI = [
  "function getAmountsOut(uint amountIn, address[] memory path) view returns (uint[] memory amounts)",
  "function swapExactTokensForTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline) returns (uint[] memory amounts)",
  "function swapExactTokensForTokensSupportingFeeOnTransferTokens(uint amountIn, uint amountOutMin, address[] calldata path, address to, uint deadline)",
  "function addLiquidity(address tokenA, address tokenB, uint amountADesired, uint amountBDesired, uint amountAMin, uint amountBMin, address to, uint deadline)"
];
