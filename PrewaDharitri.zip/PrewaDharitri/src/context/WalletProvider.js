// src/context/WalletProvider.js
import React, { createContext, useContext, useEffect, useState } from "react";
import { ethers } from "ethers";
import * as Linking from "expo-linking";
import EventEmitter from "events";

import { getWalletConnectClient } from "../wallet/walletConnectClient";

EventEmitter.defaultMaxListeners = 50;

const WalletContext = createContext();

export function WalletProvider({ children }) {
  const [client, setClient] = useState(null);
  const [session, setSession] = useState(null);
  const [address, setAddress] = useState(null);

  const [provider, setProvider] = useState(null);

  // -----------------------------------------
  // INIT WALLET CONNECT CLIENT
  // -----------------------------------------
  useEffect(() => {
    async function init() {
      try {
        const _client = await getWalletConnectClient();
        setClient(_client);
      } catch (err) {
        console.log("WalletConnect init error:", err);
      }
    }
    init();
  }, []);

  // -----------------------------------------
  // CONNECT WALLET (METAMASK MOBILE)
  // -----------------------------------------
  async function connectWallet() {
    if (!client) return;

    try {
      const { uri, approval } = await client.connect({
        optionalNamespaces: {
          eip155: {
            methods: [
              "eth_sendTransaction",
              "personal_sign",
              "eth_signTypedData"
            ],
            chains: ["eip155:97"],
            events: ["accountsChanged", "chainChanged"],
          },
        },
      });

      if (uri) {
        const deepLink = `metamask://wc?uri=${encodeURIComponent(uri)}`;
        Linking.openURL(deepLink);
      }

      const _session = await approval();
      setSession(_session);

      const acc = _session.namespaces.eip155.accounts[0].split(":")[2];
      setAddress(acc);

      const rpcUrl =
        "https://data-seed-prebsc-1-s1.binance.org:8545/";
      const _provider = new ethers.providers.JsonRpcProvider(rpcUrl);
      setProvider(_provider);

      console.log("✅ Wallet connected:", acc);

    } catch (err) {
      console.log("connectWallet error:", err);
    }
  }

  // -----------------------------------------
  // SEND TRANSACTION (ONLY VIA WALLETCONNECT)
  // -----------------------------------------
  async function sendTransaction(tx) {
    try {
      if (!client || !session || !address) {
        return { success: false, error: "Wallet not connected" };
      }

      const result = await client.request({
        topic: session.topic,
        chainId: "eip155:97",
        request: {
          method: "eth_sendTransaction",
          params: [
            {
              from: address,
              to: tx.to,
              data: tx.data,
              value: tx.value
                ? ethers.utils.hexlify(tx.value)
                : "0x0",
            },
          ],
        },
      });

      return { success: true, txHash: result };

    } catch (err) {
      console.log("sendTransaction error:", err);
      return { success: false, error: err.message };
    }
  }

  // -----------------------------------------
  // BALANCE FETCH (READ ONLY)
  // -----------------------------------------
  async function fetchTokenBalance(tokenAddress) {
    try {
      if (!provider || !address)
        return { raw: null, formatted: null };

      const ABI = [
        "function decimals() view returns (uint8)",
        "function balanceOf(address) view returns (uint256)"
      ];

      const c = new ethers.Contract(tokenAddress, ABI, provider);
      const d = await c.decimals();
      const raw = await c.balanceOf(address);

      return {
        raw,
        formatted: ethers.utils.formatUnits(raw, d),
        decimals: d
      };
    } catch (err) {
      console.log("fetchTokenBalance error:", err);
      return { raw: null, formatted: null };
    }
  }

  // -----------------------------------------
  // EXPORT
  // -----------------------------------------
  return (
    <WalletContext.Provider
      value={{
        client,
        session,
        address,
        provider,
        connectWallet,
        sendTransaction,
        fetchTokenBalance,
      }}
    >
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  return useContext(WalletContext);
}
