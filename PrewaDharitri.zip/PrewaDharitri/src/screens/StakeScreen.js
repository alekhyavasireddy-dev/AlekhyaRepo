import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
} from "react-native";
import { useTheme } from "../hooks/useTheme";

export default function StakeScreen() {
  const { theme } = useTheme();
  const styles = themedStyles(theme);

  const [selectedPlan, setSelectedPlan] = useState(90);
  const [amount, setAmount] = useState("");

  const plans = [
    { days: 90, apr: "15.00% APR", penalty: "15% Early Exit Penalty" },
    { days: 180, apr: "18.00% APR", penalty: "12% Early Exit Penalty" },
    { days: 270, apr: "22.50% APR", penalty: "8% Early Exit Penalty" },
    { days: 365, apr: "30.00% APR", penalty: "6% Early Exit Penalty" },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>Stake pREWA</Text>

      <Text style={styles.subtitle}>
        Secure the future, earn rewards. Your stake helps fund farmer services
        and the Proof-of-Stake network we're building.
      </Text>

      <View style={styles.planRow}>
        {plans.map((plan) => (
          <TouchableOpacity
            key={plan.days}
            style={[
              styles.planCard,
              selectedPlan === plan.days && styles.activePlan,
            ]}
            onPress={() => setSelectedPlan(plan.days)}
          >
            <Text style={styles.planTitle}>{plan.days} Days</Text>
            <Text style={styles.planApr}>{plan.apr}</Text>
            <Text style={styles.planPenalty}>{plan.penalty}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.stakeCard}>
        <Text style={styles.stakeTitle}>Stake Your pREWA</Text>

        <TextInput
          style={styles.input}
          placeholder="0.0 pREWA"
          placeholderTextColor={theme.subtext}
          value={amount}
          onChangeText={setAmount}
        />

        <View style={styles.percentRow}>
          {["25%", "50%", "75%", "MAX"].map((p) => (
            <TouchableOpacity key={p} style={styles.percentBtn}>
              <Text style={styles.percentText}>{p}</Text>
            </TouchableOpacity>
          ))}
        </View>

        <TouchableOpacity style={styles.actionBtn}>
          <Text style={styles.actionText}>
            {amount ? "Stake Now" : "Enter an amount"}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const themedStyles = (t) =>
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: t.background,
      padding: 16,
    },
    heading: {
      fontSize: 24,
      fontWeight: "bold",
      color: t.text,
    },
    subtitle: {
      color: t.subtext,
      marginVertical: 12,
    },
    planRow: {
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "space-between",
      marginBottom: 16,
    },
    planCard: {
      width: "48%",
      backgroundColor: t.card,
      padding: 14,
      borderRadius: 12,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: "#e5e7eb",
    },
    activePlan: {
      borderColor: "#22c55e",
      borderWidth: 2,
    },
    planTitle: {
      fontWeight: "700",
      fontSize: 16,
      color: t.text,
    },
    planApr: {
      color: "#22c55e",
      fontWeight: "600",
    },
    planPenalty: {
      color: t.subtext,
      fontSize: 12,
    },
    stakeCard: {
      backgroundColor: t.card,
      padding: 16,
      borderRadius: 12,
    },
    stakeTitle: {
      fontWeight: "700",
      marginBottom: 10,
      color: t.text,
    },
    input: {
      borderWidth: 1,
      borderColor: "#e5e7eb",
      borderRadius: 10,
      padding: 14,
      marginBottom: 10,
      color: t.text,
    },
    percentRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 10,
    },
    percentBtn: {
      paddingVertical: 6,
      paddingHorizontal: 12,
      borderRadius: 20,
      borderWidth: 1,
      borderColor: "#e5e7eb",
    },
    percentText: {
      fontSize: 12,
      fontWeight: "600",
      color: t.text,
    },
    actionBtn: {
      backgroundColor: "#22c55e",
      padding: 14,
      borderRadius: 12,
      alignItems: "center",
    },
    actionText: {
      color: "#fff",
      fontWeight: "700",
    },
  });
