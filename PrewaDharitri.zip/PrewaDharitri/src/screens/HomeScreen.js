import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  ScrollView,
  StyleSheet,
  Image,
} from "react-native";

import { useWallet } from "../context/WalletProvider";
import { PREWA_TOKEN_ADDRESS } from "../constants/token";
import { formatTokenAmount } from "../utils/format";

export default function HomeScreen() {
  const {
    address,
    connectWallet,
    fetchTokenBalance,
    addTokenToWallet,
  } = useWallet();

  const [prewa, setPrewa] = useState({
    raw: null,
    formatted: null,
    decimals: 18,
  });

  const [loading, setLoading] = useState(false);

  const loadBalance = async () => {
    if (!address) {
      setPrewa({ raw: null, formatted: null, decimals: 18 });
      return;
    }

    setLoading(true);
    const res = await fetchTokenBalance(PREWA_TOKEN_ADDRESS);

    if (res && res.formatted != null) {
      setPrewa(res);
    } else {
      setPrewa({ raw: null, formatted: null, decimals: 18 });
    }

    setLoading(false);
  };

  useEffect(() => {
    loadBalance();
  }, [address]);

  const onAddToken = async () => {
    const tokenMeta = {
      address: PREWA_TOKEN_ADDRESS,
      symbol: "pREWA",
      decimals: 18,
    };

    const result = await addTokenToWallet(tokenMeta);

    if (result.success) {
      Alert.alert("Success", "pREWA added to your wallet.");
    } else {
      Alert.alert(
        "Not Supported",
        result.message || result.error || "Your wallet cannot add tokens automatically."
      );
    }
  };

  return (
    <ScrollView style={styles.container}>

      {/* HEADER */}
      <View style={styles.header}>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Image
          source={require("../../assets/logo.png")}


            style={{ width: 35, height: 35, marginRight: 8 }}
          />
          <Text style={styles.logoText}>Dharitri</Text>
        </View>

        <Text style={styles.menuIcon}>☰</Text>
      </View>

      {/* TOKEN BAR */}
      <View style={styles.topBar}>
        <Text style={styles.topText}>pREWA</Text>

        {loading ? (
          <ActivityIndicator size="small" />
        ) : (
          <Text style={styles.topText}>
            {prewa.formatted
              ? formatTokenAmount(prewa.formatted, prewa.decimals)
              : "0"}
          </Text>
        )}

        <Text style={styles.topText}>
          {address
            ? address.slice(0, 6) + "..." + address.slice(-4)
            : "Not connected"}
        </Text>
      </View>

      {/* CONNECT WALLET */}
      {!address && (
        <TouchableOpacity onPress={connectWallet} style={styles.connectBtn}>
          <Text style={styles.connectText}>Connect Wallet</Text>
        </TouchableOpacity>
      )}

      {/* MAIN TITLE */}
      <View style={styles.titleBox}>
        <Text style={styles.mainTitle}>
          Finance for a Greener Future.
        </Text>

        <Text style={styles.subTitle}>
          Stake, swap, and manage pREWA — every action supports farmers
          with digital IDs, knowledge access, and rewards for sustainable practices.
        </Text>
      </View>

      {/* BUTTONS */}
      <View style={styles.buttonRow}>
        <TouchableOpacity style={styles.blackBtn}>
          <Text style={styles.blackBtnText}>Start Earning</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.greyBtn}>
          <Text style={styles.greyBtnText}>Fund a Green Pool</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.outlineBtn}>
        <Text style={styles.outlineText}>Track Your Impact</Text>
      </TouchableOpacity>

      {/* ADD TOKEN CARD */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Add pREWA to your wallet</Text>

        <Text style={styles.addressText}>{PREWA_TOKEN_ADDRESS}</Text>

        <TouchableOpacity onPress={onAddToken} style={styles.addBtn}>
          <Text style={styles.addBtnText}>+ Add Token</Text>
        </TouchableOpacity>
      </View>

      {/* REFRESH */}
      <TouchableOpacity onPress={loadBalance} style={styles.refreshBtn}>
        <Text style={styles.refreshText}>Refresh Balance</Text>
      </TouchableOpacity>

      {/* FOOTER */}
      <View style={styles.footer}>
        <Text style={{ fontSize: 22 }}>🔒</Text>
        <Text style={{ color: "#777", marginTop: 5 }}>
          Token secured by
        </Text>
        <Text style={styles.team}>Team Finance</Text>
      </View>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 16,
  },

  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 8,
  },

  logoText: {
    fontSize: 18,
    fontWeight: "600",
  },

  menuIcon: {
    fontSize: 26,
  },

  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: "#eee",
    paddingVertical: 8,
    marginBottom: 20,
  },

  topText: {
    fontSize: 12,
    fontWeight: "500",
  },

  connectBtn: {
    backgroundColor: "#111",
    padding: 14,
    borderRadius: 12,
    marginBottom: 20,
  },

  connectText: {
    color: "#fff",
    textAlign: "center",
    fontWeight: "600",
  },

  titleBox: {
    marginBottom: 25,
  },

  mainTitle: {
    fontSize: 26,
    fontWeight: "bold",
    textAlign: "center",
  },

  subTitle: {
    fontSize: 15,
    color: "#666",
    textAlign: "center",
    marginTop: 12,
    lineHeight: 22,
  },

  buttonRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 15,
  },

  blackBtn: {
    width: "48%",
    backgroundColor: "#000",
    padding: 14,
    borderRadius: 12,
  },

  blackBtnText: {
    textAlign: "center",
    color: "#fff",
    fontWeight: "600",
  },

  greyBtn: {
    width: "48%",
    backgroundColor: "#f2f2f2",
    padding: 14,
    borderRadius: 12,
  },

  greyBtnText: {
    textAlign: "center",
    fontWeight: "500",
  },

  outlineBtn: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 14,
    borderRadius: 12,
    marginTop: 15,
  },

  outlineText: {
    textAlign: "center",
    fontWeight: "500",
  },

  card: {
    backgroundColor: "#fafafa",
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: "#eee",
    marginTop: 25,
  },

  cardTitle: {
    fontSize: 16,
    fontWeight: "600",
  },

  addressText: {
    fontSize: 11,
    color: "#999",
    marginTop: 8,
  },

  addBtn: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 12,
    borderRadius: 10,
    marginTop: 12,
  },

  addBtnText: {
    textAlign: "center",
    fontWeight: "600",
  },

  refreshBtn: {
    backgroundColor: "#111",
    padding: 12,
    borderRadius: 10,
    marginTop: 25,
  },

  refreshText: {
    color: "#fff",
    textAlign: "center",
  },

  footer: {
    marginTop: 30,
    alignItems: "center",
  },

  team: {
    marginTop: 4,
    fontWeight: "600",
    color: "#2563eb",
  },
});
