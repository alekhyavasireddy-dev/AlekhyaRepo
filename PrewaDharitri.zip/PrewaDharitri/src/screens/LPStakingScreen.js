import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
} from "react-native";
import { useTheme } from "../hooks/useTheme";

export default function LPStakingScreen() {
  const { theme } = useTheme();
  const styles = themedStyles(theme);

  const [selectedTier, setSelectedTier] = useState(90);
  const [amount, setAmount] = useState("");

  const tiers = [
    { days: 90, apr: "24.99%", penalty: "15%" },
    { days: 180, apr: "29.99%", penalty: "12%" },
    { days: 270, apr: "37.48%", penalty: "8%" },
    { days: 365, apr: "49.98%", penalty: "6%" },
  ];

  return (
    <ScrollView style={styles.container}>

      {/* Header */}
      <Text style={styles.heading}>Stake LP Tokens</Text>
      <Text style={styles.subHeading}>
        Amplify your impact. Earn additional pREWA rewards on top of trading
        fees from your LP tokens.
      </Text>

      {/* Lock Period Cards */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ marginTop: 15 }}
      >
        {tiers.map((tier) => (
          <TouchableOpacity
            key={tier.days}
            onPress={() => setSelectedTier(tier.days)}
            style={[
              styles.tierCard,
              selectedTier === tier.days && styles.activeTier,
            ]}
          >
            <Text style={styles.tierDays}>{tier.days} Days</Text>
            <Text style={styles.apr}>{tier.apr} APR</Text>
            <Text style={styles.penalty}>
              {tier.penalty} Early Exit Penalty
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Stake Section */}
      <View style={styles.stakeCard}>

        <Text style={styles.stakeTitle}>Stake LP Tokens</Text>
        <Text style={styles.stakeSub}>
          Select a pool and amount to stake in Tier 0.
        </Text>

        {/* Pool selector (static) */}
        <View style={styles.inputBox}>
          <Text style={styles.label}>Pool to Stake</Text>
          <View style={styles.dropdown}>
            <Text style={styles.dropdownText}>
              PancakeSwap pREWA-USDT LP (Cake-LP)
            </Text>
          </View>
        </View>

        {/* Amount */}
        <View style={styles.inputBox}>
          <View style={styles.amountRow}>
            <Text style={styles.label}>Amount to Stake</Text>
            <Text style={styles.balance}>
              Balance: 0.00000000
            </Text>
          </View>

          <TextInput
            style={styles.amountInput}
            value={amount}
            onChangeText={setAmount}
            placeholder="0.0"
            placeholderTextColor="#999"
            keyboardType="numeric"
          />

          {/* Percent buttons */}
          <View style={styles.percentRow}>
            {["25%", "50%", "75%", "MAX"].map((p) => (
              <TouchableOpacity key={p} style={styles.percentBtn}>
                <Text style={styles.percentText}>{p}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Button */}
        <View style={styles.disabledBtn}>
          <Text style={styles.disabledText}>Enter an amount</Text>
        </View>

      </View>
    </ScrollView>
  );
}

const themedStyles = (t) =>
  StyleSheet.create({
    container: {
      flex: 1,
      padding: 16,
      backgroundColor: t.background,
    },

    heading: {
      fontSize: 24,
      fontWeight: "800",
      color: t.text,
    },

    subHeading: {
      marginTop: 5,
      fontSize: 14,
      color: t.subtext,
    },

    tierCard: {
      width: 220,
      padding: 16,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: "#ddd",
      marginRight: 12,
      backgroundColor: t.card,
      alignItems: "center",
    },

    activeTier: {
      borderColor: "#22c55e",
      borderWidth: 2,
    },

    tierDays: {
      fontSize: 18,
      fontWeight: "700",
      marginBottom: 5,
      color: t.text,
    },

    apr: {
      color: "#22c55e",
      fontWeight: "700",
      marginBottom: 4,
    },

    penalty: {
      fontSize: 12,
      color: t.subtext,
      textAlign: "center",
    },

    stakeCard: {
      backgroundColor: t.card,
      borderRadius: 16,
      padding: 16,
      marginTop: 30,
    },

    stakeTitle: {
      fontSize: 18,
      fontWeight: "700",
      marginBottom: 5,
      color: t.text,
    },

    stakeSub: {
      fontSize: 13,
      color: t.subtext,
      marginBottom: 20,
    },

    inputBox: {
      marginBottom: 20,
    },

    label: {
      color: t.text,
      fontWeight: "600",
      marginBottom: 6,
      fontSize: 13,
    },

    balance: {
      fontSize: 12,
      color: t.subtext,
    },

    dropdown: {
      borderWidth: 1,
      borderColor: "#ddd",
      padding: 14,
      borderRadius: 10,
      backgroundColor: "#fff",
    },

    dropdownText: {
      fontSize: 14,
      color: "#111827",
    },

    amountRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 6,
    },

    amountInput: {
      borderWidth: 1,
      borderColor: "#ddd",
      padding: 14,
      borderRadius: 10,
      backgroundColor: "#fff",
      fontSize: 14,
      color: "#000",
    },

    percentRow: {
      flexDirection: "row",
      justifyContent: "flex-end",
      marginTop: 8,
    },

    percentBtn: {
      paddingVertical: 5,
      paddingHorizontal: 12,
      backgroundColor: "#f1f5f9",
      borderRadius: 8,
      marginLeft: 8,
    },

    percentText: {
      fontSize: 12,
      fontWeight: "600",
    },

    disabledBtn: {
      backgroundColor: "#9ca3af",
      padding: 16,
      borderRadius: 10,
      alignItems: "center",
    },

    disabledText: {
      color: "#fff",
      fontWeight: "700",
    },
  });
