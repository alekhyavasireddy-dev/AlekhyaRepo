import React from "react";
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from "react-native";
import { useWallet } from "../context/WalletProvider";
import { useTheme } from "../hooks/useTheme";

export default function DashboardScreen() {
  const { address } = useWallet();
  const { theme } = useTheme();

  const styles = themedStyles(theme);

  return (
    <ScrollView style={styles.container}>

      {/* TITLE */}
      <Text style={styles.title}>Dashboard</Text>
      <Text style={styles.subtitle}>
        Track your portfolio and your impact on the Dharitri ecosystem.
      </Text>

      {/* TOP BOXES */}
      <View style={styles.topRow}>

        {/* LEFT: Protocol Impact */}
        <View style={styles.box}>
          <Text style={styles.boxTitle}>Protocol Impact (Pilot)</Text>
          <Text style={styles.boxText}>
            Early estimates while field integrations are rolling out.
          </Text>

          <View style={styles.statsRow}>
            <View style={styles.statCard}>
              <Text style={styles.statTitle}>HECTARES</Text>
              <Text style={styles.statSub}>UNDER</Text>
              <Text style={styles.statSub}>REGENERATIVE</Text>
              <Text style={styles.statSub}>PRACTICE</Text>
              <Text style={styles.statValue}>...</Text>
            </View>

            <View style={styles.statCard}>
              <Text style={styles.statTitle}>FARMERS</Text>
              <Text style={styles.statSub}>ONBOARDED</Text>
              <Text style={styles.statSub}>WITH</Text>
              <Text style={styles.statSub}>DIGITAL IDS</Text>
              <Text style={styles.statValue}>...</Text>
            </View>

            <View style={styles.statCard}>
              <Text style={styles.statTitle}>PROJECTED</Text>
              <Text style={styles.statSub}>ANNUAL CARBON</Text>
              <Text style={styles.statSub}>SEQUESTRATION</Text>
              <Text style={styles.statValue}>... tCO₂e</Text>
            </View>
          </View>

          <Text style={styles.link}>Learn more about our methodology</Text>
        </View>

        {/* RIGHT: Safety */}
        <View style={styles.box}>
          <Text style={styles.boxTitle}>Safety & Transparency</Text>

          <View style={styles.safetyGrid}>

            <TouchableOpacity style={styles.safetyItem}>
              <Text style={styles.safetyText}>View Contract</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.safetyItem}>
              <Text style={styles.safetyText}>Read Audits</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.safetyItem}>
              <Text style={styles.safetyText}>Multisig & Roles</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.safetyItem}>
              <Text style={styles.safetyText}>Risk Scanner</Text>
            </TouchableOpacity>

          </View>

          <Text style={styles.disclaimer}>
            Audits reduce risk, but don’t eliminate it.
          </Text>
        </View>

      </View>

      {/* WALLET SECTION */}
      <View style={styles.walletBox}>
        <Text style={styles.walletTitle}>Your Wallet</Text>

        <View style={styles.walletRow}>
          <Text style={styles.walletLabel}>Address:</Text>
          <Text style={styles.walletValue}>
            {address ? address.slice(0, 6) + "..." + address.slice(-4) : "Not connected"}
          </Text>
        </View>

        <View style={styles.walletRow}>
          <Text style={styles.walletLabel}>tBNB:</Text>
          <Text style={styles.walletValue}>0.287509</Text>
        </View>

        <View style={styles.walletRow}>
          <Text style={styles.walletLabel}>pREWA:</Text>
          <Text style={styles.walletValue}>115,001,619.51</Text>
        </View>

        <View style={styles.walletRow}>
          <Text style={styles.walletLabel}>USDT:</Text>
          <Text style={styles.walletValue}>0.364279</Text>
        </View>

      </View>

    </ScrollView>
  );
}

/* STYLES */
const themedStyles = (t) =>
  StyleSheet.create({
    container: {
      flex: 2,
      backgroundColor: t.background,
      padding: 20,
    },

    title: {
      fontSize: 28,
      fontWeight: "700",
      color: t.text,
      marginBottom: 10,
    },

    subtitle: {
      color: t.subtext,
      marginBottom: 35,
      fontSize: 14,
    },

    /* Top cards */
    topRow: {
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "space-between",
      gap: 20,
    },

    box: {
      backgroundColor: t.card,
      padding: 16,
      borderRadius: 14,
      width: "48%",
    },

    boxTitle: {
      fontSize: 16,
      fontWeight: "700",
      color: t.text,
      marginBottom: 8,
    },

    boxText: {
      fontSize: 13,
      color: t.subtext,
      marginBottom: 16,
    },

    statsRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 10,
    },

    statCard: {
      backgroundColor: t.background,
      padding: 10,
      borderRadius: 10,
      width: "80%",
      alignItems: "center",
    },

    statTitle: {
      fontWeight: "600",
      fontSize: 11,
      color: t.text,
    },

    statSub: {
      fontSize: 10,
      color: t.subtext,
      textAlign: "center",
    },

    statValue: {
      marginTop: 6,
      fontWeight: "700",
      color: "#22c55e",
    },

    link: {
      marginTop: 6,
      color: "#22c55e",
      fontSize: 12,
    },

    /* Safety */
    safetyGrid: {
      flexDirection: "row",
      flexWrap: "wrap",
      justifyContent: "space-between",
    },

    safetyItem: {
      width: "100%",
      backgroundColor: t.background,
      padding: 12,
      marginBottom: 10,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: "#e5e7eb",
    },

    safetyText: {
      color: t.text,
      fontWeight: "600",
      fontSize: 13,
    },

    disclaimer: {
      marginTop: 6,
      fontSize: 11,
      color: t.subtext,
    },

    /* Wallet */
    walletBox: {
      marginTop: 22,
      backgroundColor: t.card,
      borderRadius: 20,
      padding: 16,
    },

    walletTitle: {
      fontSize: 16,
      fontWeight: "700",
      marginBottom: 12,
      color: t.text,
    },

    walletRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      borderBottomWidth: 1,
      borderColor: "#e5e7eb",
      paddingVertical: 10,
    },

    walletLabel: {
      color: t.subtext,
      fontWeight: "600",
    },

    walletValue: {
      color: t.text,
      fontWeight: "600",
    },
  });
