// src/screens/AddLiquidityScreen.js
import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  Alert,
  Keyboard,
  ActivityIndicator,
} from "react-native";

import { ethers } from "ethers";
import { useWallet } from "../context/WalletProvider";

import {
  PANCAKE_ROUTER_TESTNET,
  USDT_TOKEN,
  PREWA_TOKEN,
  ERC20_ABI_MIN,
  ROUTER_V2_ABI,
} from "../constants/swap";

import TokenInput from "../components/TokenInput";
import ActionButton from "../components/ActionButton";
import SlippageSelector from "../components/SlippageSelector";

export default function AddLiquidityScreen() {
  const { address, provider, connectWallet, sendTransaction } = useWallet();

  const [amountA, setAmountA] = useState(""); // USDT
  const [amountB, setAmountB] = useState(""); // pREWA
  const [balA, setBalA] = useState("0");
  const [balB, setBalB] = useState("0");

  const [loadingTx, setLoadingTx] = useState(false);
  const [slippagePct, setSlippagePct] = useState(1);
  const [deadlineMinutes] = useState(20);

  const rpcUrl = "https://data-seed-prebsc-1-s1.binance.org:8545/";
  const readProvider =
    provider || new ethers.providers.JsonRpcProvider(rpcUrl);

  // Force decimals for stability
  const getDecimals = useCallback(
    async (token) => {
      if (token.toLowerCase() === USDT_TOKEN.toLowerCase()) return 18;
      if (token.toLowerCase() === PREWA_TOKEN.toLowerCase()) return 18;

      try {
        const c = new ethers.Contract(token, ERC20_ABI_MIN, readProvider);
        return Number(await c.decimals());
      } catch {
        return 18;
      }
    },
    [readProvider]
  );

  const fetchBalances = useCallback(async () => {
    if (!address) return;

    try {
      const cA = new ethers.Contract(USDT_TOKEN, ERC20_ABI_MIN, readProvider);
      const cB = new ethers.Contract(PREWA_TOKEN, ERC20_ABI_MIN, readProvider);

      const [decA, decB, rawA, rawB] = await Promise.all([
        getDecimals(USDT_TOKEN),
        getDecimals(PREWA_TOKEN),
        cA.balanceOf(address),
        cB.balanceOf(address),
      ]);

      setBalA(ethers.utils.formatUnits(rawA, decA));
      setBalB(ethers.utils.formatUnits(rawB, decB));
    } catch (e) {
      console.log("fetchBalances error:", e);
    }
  }, [address, readProvider, getDecimals]);

  useEffect(() => {
    fetchBalances();
  }, [address, fetchBalances]);

  // Compute minimum amounts based on slippage
  const computeMin = (bn) => {
    const basis = 10000;
    const keep = basis - Math.round(slippagePct * 100);
    return bn.mul(keep).div(basis);
  };

  // Approve token
  const approveToken = async (tokenAddr, spender, amountBN) => {
    try {
      const c = new ethers.Contract(tokenAddr, ERC20_ABI_MIN, readProvider);

      const txData = await c.populateTransaction.approve(
        spender,
        amountBN
      );

      return await sendTransaction({
        to: tokenAddr,
        data: txData.data,
      });
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const checkAllowance = async (owner, tokenAddr, spender) => {
    try {
      const c = new ethers.Contract(tokenAddr, ERC20_ABI_MIN, readProvider);
      return await c.allowance(owner, spender);
    } catch {
      return ethers.constants.Zero;
    }
  };

  const addLiquidity = async () => {
    Keyboard.dismiss();

    if (!address) return Alert.alert("Connect wallet");
    if (!amountA || !amountB) return Alert.alert("Enter both amounts");

    try {
      setLoadingTx(true);

      const net = await readProvider.getNetwork();
      if (net.chainId !== 97) {
        return Alert.alert("Switch to BNB Testnet (97)");
      }

      const decA = await getDecimals(USDT_TOKEN);
      const decB = await getDecimals(PREWA_TOKEN);

      const amountABN = ethers.utils.parseUnits(amountA, decA);
      const amountBBN = ethers.utils.parseUnits(amountB, decB);

      const balABN = ethers.utils.parseUnits(
        parseFloat(balA || "0").toFixed(decA),
        decA
      );
      const balBBN = ethers.utils.parseUnits(
        parseFloat(balB || "0").toFixed(decB),
        decB
      );

      if (amountABN.gt(balABN))
        return Alert.alert("USDT amount exceeds your balance");

      if (amountBBN.gt(balBBN))
        return Alert.alert("pREWA amount exceeds your balance");

      // APPROVALS
      const allowanceA = await checkAllowance(
        address,
        USDT_TOKEN,
        PANCAKE_ROUTER_TESTNET
      );

      if (allowanceA.lt(amountABN)) {
        const res = await approveToken(
          USDT_TOKEN,
          PANCAKE_ROUTER_TESTNET,
          ethers.constants.MaxUint256
        );
        if (!res.success) throw new Error(res.error);
      }

      const allowanceB = await checkAllowance(
        address,
        PREWA_TOKEN,
        PANCAKE_ROUTER_TESTNET
      );

      if (allowanceB.lt(amountBBN)) {
        const res = await approveToken(
          PREWA_TOKEN,
          PANCAKE_ROUTER_TESTNET,
          ethers.constants.MaxUint256
        );
        if (!res.success) throw new Error(res.error);
      }

      // Build TX for addLiquidity()
      const iface = new ethers.utils.Interface(ROUTER_V2_ABI);

      const minA = computeMin(amountABN);
      const minB = computeMin(amountBBN);

      const deadline = Math.floor(Date.now() / 1000) + deadlineMinutes * 60;

      const data = iface.encodeFunctionData("addLiquidity", [
        USDT_TOKEN,
        PREWA_TOKEN,
        amountABN,
        amountBBN,
        minA,
        minB,
        address,
        deadline,
      ]);

      const res = await sendTransaction({
        to: PANCAKE_ROUTER_TESTNET,
        data,
      });

      if (!res.success) throw new Error(res.error);

      Alert.alert(
        "Success",
        "Liquidity Added Successfully!\nTx: " + res.txHash
      );

      setAmountA("");
      setAmountB("");
      setTimeout(fetchBalances, 3000);
    } catch (err) {
      console.log("AddLiquidity error:", err);
      Alert.alert("Error", err.message || String(err));
    } finally {
      setLoadingTx(false);
    }
  };

  const isDisabled = () => {
    if (loadingTx) return true;
    if (!amountA || !amountB) return true;
    if (Number(amountA) > Number(balA)) return true;
    if (Number(amountB) > Number(balB)) return true;
    return false;
  };

  return (
    <View style={{ padding: 16 }}>
      {!address && (
        <ActionButton title="Connect Wallet" onPress={connectWallet} />
      )}

      <Text style={{ fontSize: 20, fontWeight: "700", marginBottom: 10 }}>
        Add Liquidity
      </Text>

      <TokenInput
        value={amountA}
        onChange={setAmountA}
        tokenSymbol="USDT"
        balance={balA}
      />

      <View style={{ alignItems: "center", marginVertical: 16 }}>
        <Text>USDT ↔ pREWA</Text>
      </View>

      <TokenInput
        value={amountB}
        onChange={setAmountB}
        tokenSymbol="pREWA"
        balance={balB}
      />

      <SlippageSelector value={slippagePct} onChange={setSlippagePct} />

      <ActionButton
        title="Add Liquidity"
        onPress={addLiquidity}
        loading={loadingTx}
        disabled={isDisabled()}
      />
    </View>
  );
}
