import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { useTheme } from "../hooks/useTheme";

export default function VestingScreen() {
  const { theme } = useTheme();
  const styles = themedStyles(theme);

  const [beneficiary, setBeneficiary] = useState("");
  const [amount, setAmount] = useState("");
  const [date, setDate] = useState("");
  const [duration, setDuration] = useState("");
  const [cliff, setCliff] = useState("");
  const [revocable, setRevocable] = useState(true);

  return (
    <ScrollView style={styles.container}>

      {/* PAGE TITLE */}
      <Text style={styles.heading}>Token Vesting</Text>
      <Text style={styles.subHead}>
        Create and manage vesting schedules for your pREWA tokens.
      </Text>

      {/* CARD */}
      <View style={styles.card}>

        <Text style={styles.cardTitle}>
          Create New Vesting Schedule (Admin)
        </Text>

        {/* Beneficiary + Amount */}
        <View style={styles.row}>

          <View style={styles.col}>
            <Text style={styles.label}>Beneficiary Address</Text>
            <TextInput
              style={styles.input}
              placeholder="0x..."
              placeholderTextColor="#9ca3af"
              value={beneficiary}
              onChangeText={setBeneficiary}
            />
          </View>

          <View style={styles.col}>
            <View style={styles.balanceRow}>
              <Text style={styles.label}>Amount to Vest</Text>
              <Text style={styles.balance}>
                Balance: 0.00
              </Text>
            </View>

            <TextInput
              style={styles.input}
              placeholder="0.0 pREWA"
              placeholderTextColor="#9ca3af"
              value={amount}
              onChangeText={setAmount}
              keyboardType="numeric"
            />
          </View>

        </View>

        {/* Date + Duration */}
        <View style={styles.row}>

          <View style={styles.col}>
            <Text style={styles.label}>Start Date (Optional)</Text>
            <TextInput
              style={styles.input}
              placeholder="dd-mm-yyyy"
              placeholderTextColor="#9ca3af"
              value={date}
              onChangeText={setDate}
            />
          </View>

          <View style={styles.col}>
            <Text style={styles.label}>Duration (Days)</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., 365"
              placeholderTextColor="#9ca3af"
              value={duration}
              onChangeText={setDuration}
              keyboardType="numeric"
            />
          </View>

        </View>

        {/* Cliff + Revocable */}
        <View style={styles.row}>

          <View style={styles.col}>
            <Text style={styles.label}>Cliff (Days)</Text>
            <TextInput
              style={styles.input}
              placeholder="e.g., 90"
              placeholderTextColor="#9ca3af"
              value={cliff}
              onChangeText={setCliff}
              keyboardType="numeric"
            />
          </View>

          <View style={styles.col}>
            <TouchableOpacity
              style={styles.checkboxRow}
              onPress={() => setRevocable(!revocable)}
            >
              <View
                style={[
                  styles.checkbox,
                  revocable && styles.checkboxActive,
                ]}
              />
              <Text style={styles.checkboxText}>Revocable</Text>
            </TouchableOpacity>
          </View>

        </View>

        {/* BUTTON */}
        <View style={styles.disabledBtn}>
          <Text style={styles.disabledText}>Create Schedule</Text>
        </View>

      </View>

      {/* SECOND SECTION PLACEHOLDER */}
      <View style={styles.listCard}>
        <View style={styles.listHeader}>
          <Text style={styles.listTitle}>Your Vesting Schedules (0)</Text>
          <Text style={styles.usdText}>~$0.00 USD</Text>
        </View>

        <View style={styles.emptyBox}>
          <Text style={styles.emptyText}>
            No vesting schedules found
          </Text>
        </View>
      </View>

    </ScrollView>
  );
}

const themedStyles = (t) =>
  StyleSheet.create({
    container: {
      flex: 1,
      padding: 16,
      backgroundColor: t.background,
    },

    heading: {
      fontSize: 24,
      fontWeight: "800",
      color: t.text,
    },

    subHead: {
      marginTop: 5,
      marginBottom: 20,
      fontSize: 14,
      color: t.subtext,
    },

    card: {
      backgroundColor: t.card,
      borderRadius: 16,
      padding: 16,
    },

    cardTitle: {
      fontSize: 16,
      fontWeight: "700",
      marginBottom: 20,
      color: t.text,
    },

    row: {
      flexDirection: "row",
      gap: 10,
      marginBottom: 15,
    },

    col: {
      flex: 1,
    },

    label: {
      fontSize: 13,
      fontWeight: "600",
      marginBottom: 6,
      color: t.text,
    },

    input: {
      borderWidth: 1,
      borderColor: "#e5e7eb",
      padding: 12,
      borderRadius: 10,
      backgroundColor: "#fff",
    },

    balanceRow: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 6,
    },

    balance: {
      fontSize: 11,
      color: t.subtext,
    },

    checkboxRow: {
      flexDirection: "row",
      alignItems: "center",
      marginTop: 22,
    },

    checkbox: {
      width: 18,
      height: 18,
      borderRadius: 4,
      borderWidth: 1,
      borderColor: "#9ca3af",
      marginRight: 8,
    },

    checkboxActive: {
      backgroundColor: "#2563eb",
      borderColor: "#2563eb",
    },

    checkboxText: {
      fontSize: 14,
      color: t.text,
    },

    disabledBtn: {
      marginTop: 15,
      padding: 16,
      borderRadius: 10,
      backgroundColor: "#9ca3af",
      alignItems: "center",
    },

    disabledText: {
      color: "#fff",
      fontWeight: "700",
    },

    listCard: {
      marginTop: 30,
      backgroundColor: t.card,
      borderRadius: 16,
      padding: 16,
    },

    listHeader: {
      flexDirection: "row",
      justifyContent: "space-between",
      marginBottom: 15,
    },

    listTitle: {
      fontWeight: "700",
      fontSize: 16,
      color: t.text,
    },

    usdText: {
      fontSize: 13,
      color: t.subtext,
    },

    emptyBox: {
      padding: 30,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: "#e5e7eb",
      alignItems: "center",
    },

    emptyText: {
      color: t.subtext,
    },
  });
