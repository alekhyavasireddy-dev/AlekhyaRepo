// src/screens/SwapScreen.js
import React, { useState, useEffect, useCallback } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Keyboard,
} from "react-native";
import { ethers } from "ethers";
import { useWallet } from "../context/WalletProvider";

import {
  USDT_TOKEN,
  PREWA_TOKEN,
  PANCAKE_ROUTER_TESTNET,
  ERC20_ABI_MIN,
  ROUTER_V2_ABI,
} from "../constants/swap";

export default function SwapScreen() {
  const { address, provider, connectWallet, sendTransaction } = useWallet();

  // UI state
  const [selectedFrom, setSelectedFrom] = useState("USDT"); // or "pREWA"
  const [fromAmount, setFromAmount] = useState("");
  const [estimatedOut, setEstimatedOut] = useState("0");
  const [isLoadingQuote, setIsLoadingQuote] = useState(false);
  const [isSwapping, setIsSwapping] = useState(false);
  const [isApproving, setIsApproving] = useState(false);

  const [balUSDT, setBalUSDT] = useState("0");
  const [balPREWA, setBalPREWA] = useState("0");

  const rpcUrl = "https://data-seed-prebsc-1-s1.binance.org:8545/";
  const readProvider = provider || new ethers.providers.JsonRpcProvider(rpcUrl);

  // token helpers
  const tokenAddress = (symbol) =>
    symbol === "USDT" ? USDT_TOKEN : PREWA_TOKEN;

  const getDecimals = useCallback(
    async (token) => {
      // both are 18 for your constants (we force 18), but fallback to on-chain read
      try {
        if (token.toLowerCase() === USDT_TOKEN.toLowerCase()) return 18;
        if (token.toLowerCase() === PREWA_TOKEN.toLowerCase()) return 18;

        const c = new ethers.Contract(token, ERC20_ABI_MIN, readProvider);
        const dec = await c.decimals();
        return Number(dec);
      } catch {
        return 18;
      }
    },
    [readProvider]
  );

  const fetchBalances = useCallback(async () => {
    if (!address) {
      setBalUSDT("0");
      setBalPREWA("0");
      return;
    }
    try {
      const cA = new ethers.Contract(USDT_TOKEN, ERC20_ABI_MIN, readProvider);
      const cB = new ethers.Contract(PREWA_TOKEN, ERC20_ABI_MIN, readProvider);

      const [decA, decB, rawA, rawB] = await Promise.all([
        getDecimals(USDT_TOKEN),
        getDecimals(PREWA_TOKEN),
        cA.balanceOf(address),
        cB.balanceOf(address),
      ]);

      setBalUSDT(ethers.utils.formatUnits(rawA, decA));
      setBalPREWA(ethers.utils.formatUnits(rawB, decB));
    } catch (e) {
      console.log("fetchBalances err:", e);
    }
  }, [address, readProvider, getDecimals]);

  useEffect(() => {
    fetchBalances();
  }, [address, fetchBalances]);

  // Toggle direction
  const toggleDirection = () => {
    setSelectedFrom((s) => (s === "USDT" ? "pREWA" : "USDT"));
    setFromAmount("");
    setEstimatedOut("0");
  };

  // Quote using router.getAmountsOut (read-only)
  useEffect(() => {
    let mounted = true;
    const doQuote = async () => {
      setEstimatedOut("0");
      if (!fromAmount || Number(fromAmount) <= 0) return;
      const fromSymbol = selectedFrom;
      const toSymbol = selectedFrom === "USDT" ? "pREWA" : "USDT";

      const fromAddr = tokenAddress(fromSymbol);
      const toAddr = tokenAddress(toSymbol);

      try {
        setIsLoadingQuote(true);

        const decFrom = await getDecimals(fromAddr);
        const decTo = await getDecimals(toAddr);

        const amountIn = ethers.utils.parseUnits(fromAmount, decFrom);

        const router = new ethers.Contract(
          PANCAKE_ROUTER_TESTNET,
          ROUTER_V2_ABI,
          readProvider
        );

        // getAmountsOut might revert if no pool, so catch
        const amounts = await router.getAmountsOut(amountIn, [fromAddr, toAddr]);
        if (!mounted) return;

        const outBn = amounts[amounts.length - 1];
        const formatted = ethers.utils.formatUnits(outBn, decTo);
        setEstimatedOut(formatted);
      } catch (err) {
        // Could be revert (no pool) or other error
        console.log("quote err:", err);
        setEstimatedOut("0");
      } finally {
        if (mounted) setIsLoadingQuote(false);
      }
    };

    doQuote();
    return () => {
      mounted = false;
    };
  }, [fromAmount, selectedFrom, readProvider, getDecimals]);

  // Check allowance helper
  const getAllowance = async (owner, tokenAddr, spender) => {
    try {
      const c = new ethers.Contract(tokenAddr, ERC20_ABI_MIN, readProvider);
      const al = await c.allowance(owner, spender);
      return al;
    } catch (e) {
      console.log("allowance err", e);
      return ethers.constants.Zero;
    }
  };

  // Approve helper using sendTransaction (like AddLiquidity)
  const approveIfNeeded = async (owner, tokenAddr, spender, neededAmountBN) => {
    try {
      const allowance = await getAllowance(owner, tokenAddr, spender);
      if (allowance.gte(neededAmountBN)) return { ok: true, txHash: null };

      const c = new ethers.Contract(tokenAddr, ERC20_ABI_MIN, readProvider);
      const txData = await c.populateTransaction.approve(
        spender,
        ethers.constants.MaxUint256
      );

      setIsApproving(true);
      const res = await sendTransaction({ to: tokenAddr, data: txData.data });
      if (!res.success) {
        setIsApproving(false);
        return { ok: false, error: res.error };
      }
      // Wait for a short while (you can also poll or set up a receipt watch)
      // Simple wait: poll the provider for the tx receipt
      const signerProvider = provider || new ethers.providers.JsonRpcProvider(rpcUrl);
      const receipt = await signerProvider.waitForTransaction(res.txHash, 1, 60000).catch(() => null);
      setIsApproving(false);
      if (!receipt) {
        // still ok — but we request user to wait
        return { ok: true, txHash: res.txHash };
      }
      // success
      return { ok: true, txHash: res.txHash };
    } catch (err) {
      setIsApproving(false);
      console.log("approve err", err);
      return { ok: false, error: err?.message || String(err) };
    }
  };

  // Swap function (ERC20 <-> ERC20 only)
  const handleSwap = async () => {
    Keyboard.dismiss();

    if (!address) {
      return Alert.alert("Wallet", "Connect your wallet first", [
        { text: "Connect", onPress: () => connectWallet() },
        { text: "Cancel" },
      ]);
    }

    if (!fromAmount || Number(fromAmount) <= 0) {
      return Alert.alert("Input", "Enter a valid amount");
    }

    if (estimatedOut === "0") {
      return Alert.alert("Quote", "No quote available (pool might not exist)");
    }

    try {
      setIsSwapping(true);

      const fromSymbol = selectedFrom;
      const toSymbol = selectedFrom === "USDT" ? "pREWA" : "USDT";

      const fromAddr = tokenAddress(fromSymbol);
      const toAddr = tokenAddress(toSymbol);

      const decFrom = await getDecimals(fromAddr);
      const decTo = await getDecimals(toAddr);

      const amountInBN = ethers.utils.parseUnits(fromAmount, decFrom);
      const amountOutBN = ethers.utils.parseUnits(estimatedOut, decTo);

      // apply slippage (use 0.5% by default — adjust if you want)
      const slippageBps = 50; // 50 bps = 0.5%
      const amountOutMin = amountOutBN.mul(10000n - BigInt(slippageBps)).div(10000n);

      // ensure approval for from token (if from token is ERC20)
      // both tokens are ERC20 in this screen (USDT & pREWA)
      const approveResult = await approveIfNeeded(
        address,
        fromAddr,
        PANCAKE_ROUTER_TESTNET,
        amountInBN
      );
      if (!approveResult.ok) {
        throw new Error(approveResult.error || "Approve failed");
      }

      // encode swapExactTokensForTokens
      const iface = new ethers.utils.Interface(ROUTER_V2_ABI);

      const deadline = Math.floor(Date.now() / 1000) + 60 * 10; // 10 minutes
      const data = iface.encodeFunctionData("swapExactTokensForTokens", [
        amountInBN,
        amountOutMin,
        [fromAddr, toAddr],
        address,
        deadline,
      ]);

      // send transaction via your provider helper
      const res = await sendTransaction({
        to: PANCAKE_ROUTER_TESTNET,
        data,
      });

      if (!res.success) throw new Error(res.error || "Tx failed");

      // wait for confirmation (optional)
      const signerProvider = provider || new ethers.providers.JsonRpcProvider(rpcUrl);
      await signerProvider.waitForTransaction(res.txHash, 1, 60000).catch(() => null);

      Alert.alert("Success", "Swap completed!\nTx: " + res.txHash);
      setFromAmount("");
      setEstimatedOut("0");
      fetchBalances();
    } catch (err) {
      console.log("swap err:", err);
      Alert.alert("Swap Error", err?.message || String(err));
    } finally {
      setIsSwapping(false);
      setIsApproving(false);
    }
  };

  // UI helpers
  const fromBalance = selectedFrom === "USDT" ? balUSDT : balPREWA;
  const toBalance = selectedFrom === "USDT" ? balPREWA : balUSDT;

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <Text style={{ fontSize: 22, fontWeight: "700", marginBottom: 12 }}>
        Swap
      </Text>

      <View style={{ marginBottom: 10 }}>
        <Text style={{ marginBottom: 6 }}>From ({selectedFrom})</Text>
        <TextInput
          value={fromAmount}
          onChangeText={setFromAmount}
          placeholder="0.0"
          keyboardType="numeric"
          style={{
            borderWidth: 1,
            borderRadius: 8,
            padding: 10,
          }}
        />
        <Text style={{ marginTop: 6, color: "#666" }}>
          Balance: {fromBalance}
        </Text>
      </View>

      <View style={{ alignItems: "center", marginVertical: 8 }}>
        <TouchableOpacity onPress={toggleDirection} style={{ padding: 8 }}>
          <Text style={{ color: "#007bff", fontWeight: "700" }}>Swap ↕</Text>
        </TouchableOpacity>
      </View>

      <View style={{ marginBottom: 14 }}>
        <Text style={{ marginBottom: 6 }}>
          To ({selectedFrom === "USDT" ? "pREWA" : "USDT"})
        </Text>
        <View
          style={{
            borderWidth: 1,
            borderRadius: 8,
            padding: 10,
            minHeight: 48,
            justifyContent: "center",
          }}
        >
          {isLoadingQuote ? (
            <ActivityIndicator />
          ) : (
            <Text>{estimatedOut}</Text>
          )}
        </View>
        <Text style={{ marginTop: 6, color: "#666" }}>Balance: {toBalance}</Text>
      </View>

      <View style={{ marginTop: 12 }}>
        <TouchableOpacity
          onPress={handleSwap}
          disabled={isSwapping || isApproving}
          style={{
            backgroundColor: "#00c853",
            padding: 14,
            borderRadius: 10,
            alignItems: "center",
            opacity: isSwapping || isApproving ? 0.7 : 1,
            marginBottom: 8,
          }}
        >
          {isSwapping ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={{ color: "#fff", fontWeight: "700" }}>Swap</Text>
          )}
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() =>
            Alert.alert(
              "Info",
              `You are swapping ${selectedFrom} → ${
                selectedFrom === "USDT" ? "pREWA" : "USDT"
              }`
            )
          }
          style={{
            padding: 12,
            borderRadius: 8,
            borderWidth: 1,
            borderColor: "#ddd",
            alignItems: "center",
          }}
        >
          <Text>Details</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
