// screens/WalletScreen.js (partial)
import React, { useEffect, useState } from "react";
import { View, Text, TouchableOpacity, ActivityIndicator } from "react-native";
import { useWallet } from "../context/WalletProvider";
import { PREWA_TOKEN_ADDRESS } from "../constants/token";
import { formatTokenAmount } from "../utils/format";

export default function WalletScreen() {
  const { address, fetchTokenBalance } = useWallet();
  const [prewa, setPrewa] = useState({ raw: null, formatted: null, decimals: 18 });
  const [loading, setLoading] = useState(false);

  const loadBalance = async () => {
    if (!address) {
      setPrewa({ raw: null, formatted: null });
      return;
    }
    setLoading(true);
    const res = await fetchTokenBalance(PREWA_TOKEN_ADDRESS);
    if (res && res.formatted != null) setPrewa(res);
    setLoading(false);
  };

  useEffect(() => {
    loadBalance();
  }, [address]);

  return (
    <View style={{ padding: 16 }}>
      <Text style={{ fontSize: 18, fontWeight: "600", marginBottom: 8 }}>Wallet</Text>

      <View style={{ padding: 12, borderRadius: 8, backgroundColor: "#fff", shadowColor: "#000" }}>
        <Text style={{ fontSize: 14, color: "#666" }}>pREWA balance</Text>

        {loading ? (
          <ActivityIndicator />
        ) : (
          <Text style={{ fontSize: 20, fontWeight: "700" }}>
            {prewa.formatted ? formatTokenAmount(prewa.formatted, prewa.decimals) : "—"} pREWA
          </Text>
        )}

        <TouchableOpacity onPress={loadBalance} style={{ marginTop: 8 }}>
          <Text style={{ color: "#007bff" }}>Refresh</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
