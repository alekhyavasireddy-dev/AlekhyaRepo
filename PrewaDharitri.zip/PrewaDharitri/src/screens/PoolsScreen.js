// src/screens/PoolsScreen.js
import React, { useState, useEffect, useCallback } from "react";
import { View, Text, Alert, Keyboard, StyleSheet } from "react-native";
import { ethers } from "ethers";
import { useWallet } from "../context/WalletProvider";
import { useTheme } from "../hooks/useTheme";

import {
  PANCAKE_ROUTER_TESTNET,
  USDT_TOKEN,
  PREWA_TOKEN,
  ERC20_ABI_MIN,
  ROUTER_V2_ABI,
} from "../constants/swap";

import TokenInput from "../components/TokenInput";
import ActionButton from "../components/ActionButton";
import SlippageSelector from "../components/SlippageSelector";

export default function PoolsScreen() {
  const { theme } = useTheme();
  const styles = themedStyles(theme);

  const { address, provider, connectWallet, sendTransaction } = useWallet();

  const [amountA, setAmountA] = useState(""); // USDT
  const [amountB, setAmountB] = useState(""); // pREWA

  const [balA, setBalA] = useState("0");
  const [balB, setBalB] = useState("0");

  const [loadingTx, setLoadingTx] = useState(false);
  const [slippagePct, setSlippagePct] = useState(1);

  const rpcUrl = "https://data-seed-prebsc-1-s1.binance.org:8545/";

  // ✅ ONLY for reads
  const readProvider = new ethers.providers.JsonRpcProvider(rpcUrl);

  // ✅ ONLY for writes (MetaMask / WalletConnect)
 const writeProvider = provider ? new ethers.providers.Web3Provider(provider) : null;


  const getDecimals = useCallback(
    async (token) => {
      if (token.toLowerCase() === USDT_TOKEN.toLowerCase()) return 6;
      if (token.toLowerCase() === PREWA_TOKEN.toLowerCase()) return 18;

      try {
        const c = new ethers.Contract(token, ERC20_ABI_MIN, readProvider);
        return Number(await c.decimals());
      } catch {
        return 18;
      }
    },
    [readProvider]
  );

  const fetchBalances = useCallback(async () => {
    if (!address) return;

    try {
      const cA = new ethers.Contract(USDT_TOKEN, ERC20_ABI_MIN, readProvider);
      const cB = new ethers.Contract(PREWA_TOKEN, ERC20_ABI_MIN, readProvider);

      const [decA, decB, rawA, rawB] = await Promise.all([
        getDecimals(USDT_TOKEN),
        getDecimals(PREWA_TOKEN),
        cA.balanceOf(address),
        cB.balanceOf(address),
      ]);

      setBalA(ethers.utils.formatUnits(rawA, decA));
      setBalB(ethers.utils.formatUnits(rawB, decB));
    } catch (e) {
      console.log("Balance error:", e);
    }
  }, [address, readProvider, getDecimals]);

  useEffect(() => {
    fetchBalances();
  }, [address, fetchBalances]);

  const computeMin = (bn) => {
    const basis = 10000;
    const keep = basis - Math.round(slippagePct * 100);
    return bn.mul(keep).div(basis);
  };

  const checkAllowance = async (owner, tokenAddr, spender) => {
    try {
      const c = new ethers.Contract(tokenAddr, ERC20_ABI_MIN, readProvider);
      return await c.allowance(owner, spender);
    } catch {
      return ethers.constants.Zero;
    }
  };

  // ✅ FIXED — uses writeProvider signer
  const approveToken = async (tokenAddr, spender) => {
    try {
      const signer = writeProvider.getSigner();
      const t = new ethers.Contract(tokenAddr, ERC20_ABI_MIN, signer);
      const txData = await t.populateTransaction.approve(
        spender,
        ethers.constants.MaxUint256
      );

      return await sendTransaction({ to: tokenAddr, data: txData.data });
    } catch (err) {
      return { success: false, error: err.message };
    }
  };

  const addLiquidity = async () => {
    Keyboard.dismiss();

    if (!address) return Alert.alert("Connect your wallet");
    if (!writeProvider) return Alert.alert("Reconnect your wallet");
    if (!amountA || !amountB) return Alert.alert("Enter both amounts");

    try {
      setLoadingTx(true);

      // ✅ Network check via wallet
      const net = await writeProvider.getSigner().provider.getNetwork();

      if (net.chainId !== 97) {
        return Alert.alert("Switch to BNB Testnet (97)");
      }

      const decA = await getDecimals(USDT_TOKEN);
      const decB = await getDecimals(PREWA_TOKEN);

      const amountABN = ethers.utils.parseUnits(amountA, decA);
      const amountBBN = ethers.utils.parseUnits(amountB, decB);

      const balABN = ethers.utils.parseUnits(
        parseFloat(balA || "0").toFixed(decA),
        decA
      );

      const balBBN = ethers.utils.parseUnits(
        parseFloat(balB || "0").toFixed(decB),
        decB
      );

      if (amountABN.gt(balABN))
        return Alert.alert("USDT amount exceeds balance");

      if (amountBBN.gt(balBBN))
        return Alert.alert("pREWA amount exceeds balance");

      // ✅ Approval for USDT
      const allowanceA = await checkAllowance(
        address,
        USDT_TOKEN,
        PANCAKE_ROUTER_TESTNET
      );

      if (allowanceA.lt(amountABN)) {
        const res = await approveToken(
          USDT_TOKEN,
          PANCAKE_ROUTER_TESTNET
        );
        if (!res.success) throw new Error(res.error);
      }

      // ✅ Approval for pREWA
      const allowanceB = await checkAllowance(
        address,
        PREWA_TOKEN,
        PANCAKE_ROUTER_TESTNET
      );

      if (allowanceB.lt(amountBBN)) {
        const res = await approveToken(
          PREWA_TOKEN,
          PANCAKE_ROUTER_TESTNET
        );
        if (!res.success) throw new Error(res.error);
      }

      const iface = new ethers.utils.Interface(ROUTER_V2_ABI);

      const minA = computeMin(amountABN);
      const minB = computeMin(amountBBN);
      const deadline = Math.floor(Date.now() / 1000) + 20 * 60;

      const data = iface.encodeFunctionData("addLiquidity", [
        USDT_TOKEN,
        PREWA_TOKEN,
        amountABN,
        amountBBN,
        minA,
        minB,
        address,
        deadline,
      ]);

      await new Promise((r) => setTimeout(r, 800));

      const res = await sendTransaction({
        to: PANCAKE_ROUTER_TESTNET,
        data,
      });

      if (!res.success) throw new Error(res.error);

      Alert.alert("✅ Success", "Liquidity Added Successfully!");

      setAmountA("");
      setAmountB("");
      setTimeout(fetchBalances, 4000);
    } catch (err) {
      console.log("Liquidity error:", err);
      Alert.alert("Add Liquidity Error", err.message || String(err));
    } finally {
      setLoadingTx(false);
    }
  };

  const onPercentA = (p) => {
    const val = (Number(balA) * p).toFixed(6).replace(/\.?0+$/, "");
    setAmountA(val);
  };

  const onPercentB = (p) => {
    const val = (Number(balB) * p).toFixed(6).replace(/\.?0+$/, "");
    setAmountB(val);
  };

  return (
    <View style={styles.container}>
      {!address && (
        <ActionButton title="Connect Wallet" onPress={connectWallet} />
      )}

      <Text style={styles.title}>Provide Liquidity</Text>

      <TokenInput
        value={amountA}
        onChange={setAmountA}
        tokenSymbol="USDT"
        balance={balA}
        onPercent={onPercentA}
      />

      <Text style={styles.plus}>+</Text>

      <TokenInput
        value={amountB}
        onChange={setAmountB}
        tokenSymbol="pREWA"
        balance={balB}
        onPercent={onPercentB}
      />

      <SlippageSelector value={slippagePct} onChange={setSlippagePct} />

      <ActionButton
        title="Add Liquidity"
        onPress={addLiquidity}
        loading={loadingTx}
        disabled={loadingTx}
      />
    </View>
  );
}

const themedStyles = (t) =>
  StyleSheet.create({
    container: {
      flex: 1,
      padding: 16,
      backgroundColor: t.background,
    },
    title: {
      fontSize: 22,
      fontWeight: "700",
      color: t.text,
      marginBottom: 10,
      textAlign: "center",
    },
    plus: {
      fontSize: 28,
      textAlign: "center",
      marginVertical: 10,
      color: t.text,
    },
  });
