import { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';

export default function SplashScreen({ navigation }) {
  useEffect(() => {
    const timer = setTimeout(() => {
      navigation.replace('WalletConnect'); // move to next screen
    }, 2000); // 2 seconds delay
    return () => clearTimeout(timer);
  }, [navigation]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🌍 Prewa Dharitri</Text>
      <ActivityIndicator size="large" color="#007BFF" style={{ marginTop: 20 }} />
      <Text style={styles.subtitle}>Connecting to blockchain...</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  title: { fontSize: 28, fontWeight: 'bold', color: '#007BFF' },
  subtitle: { marginTop: 10, fontSize: 14, color: '#555' },
});
