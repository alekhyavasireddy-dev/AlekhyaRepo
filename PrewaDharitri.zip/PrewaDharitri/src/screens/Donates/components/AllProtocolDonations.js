import React from "react"
import { View, Text, StyleSheet } from "react-native"

export default function AllProtocolDonations() {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>All Protocol Donations</Text>

      <View style={styles.row}>
        <Text style={styles.header}>Date</Text>
        <Text style={styles.header}>Asset</Text>
        <Text style={styles.header}>Amount</Text>
      </View>

      {/* Dummy Data */}
      <View style={styles.row}>
        <Text>2025-11-12</Text>
        <Text>pREWA</Text>
        <Text>999</Text>
      </View>

      <View style={styles.row}>
        <Text>2025-10-09</Text>
        <Text>tBNB</Text>
        <Text>0.001</Text>
      </View>

    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#ffffff",
    padding: 20,
    borderRadius: 12,
    marginBottom: 50,
    elevation: 3
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 15,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  header: {
    fontWeight: "bold",
  },
})
