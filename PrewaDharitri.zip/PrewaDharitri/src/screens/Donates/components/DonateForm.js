import React from "react"
import { View, Text, TextInput, StyleSheet, TouchableOpacity } from "react-native"

export default function DonateForm() {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>Directly Fund a Greener Planet</Text>

      <Text style={styles.note}>
        100% of donations are allocated to farmer services, on-chain carbon
        credit projects, and community grants.
      </Text>

      {/* Name row */}
      <View style={styles.row}>
        <TextInput style={[styles.input, { flex: 1 }]} placeholder="First Name*" />
        <TextInput style={[styles.input, { flex: 1 }]} placeholder="Middle Name" />
        <TextInput style={[styles.input, { flex: 1 }]} placeholder="Last Name*" />
      </View>

      <TextInput style={styles.inputFull} placeholder="Street Address*" />

      <View style={styles.row}>
        <TextInput style={[styles.input, { flex: 1 }]} placeholder="City*" />
        <TextInput style={[styles.input, { flex: 1 }]} placeholder="Postal Code" />
      </View>

      <TextInput style={styles.inputFull} placeholder="Country*" />

      {/* Asset + Amount */}
      <View style={styles.row}>
        <TextInput style={[styles.input, { flex: 1 }]} placeholder="Asset (BNB)" />
        <TextInput
          style={[styles.input, { flex: 1 }]}
          placeholder="Amount"
          keyboardType="numeric"
        />
      </View>

      <TextInput
        style={styles.inputFull}
        placeholder="Email (optional - for certificate)"
      />

      {/* Contract Address */}
      <Text style={styles.label}>Donation Contract</Text>
      <TextInput
        style={styles.inputFull}
        value="0x53F0F3A3aeC235556837510EC71969dA3b1b4Aa2"
        editable={false}
      />

      {/* Donate Button */}
      <TouchableOpacity style={styles.button}>
        <Text style={styles.buttonText}>Donate</Text>
      </TouchableOpacity>
    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#ffffff",
    padding: 20,
    borderRadius: 12,
    marginBottom: 30,
    elevation: 3
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 10,
  },
  note: {
    fontSize: 13,
    color: "#444",
    marginBottom: 15,
  },
  row: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: "#e5e5e5",
    borderRadius: 8,
    padding: 10,
  },
  inputFull: {
    borderWidth: 1,
    borderColor: "#e5e5e5",
    borderRadius: 8,
    padding: 10,
    marginBottom: 12,
  },
  label: {
    fontSize: 14,
    marginBottom: 5,
    color: "#555",
  },
  button: {
    backgroundColor: "#A8E6A3",
    padding: 15,
    alignItems: "center",
    borderRadius: 10,
    marginTop: 10,
  },
  buttonText: {
    color: "#000",
    fontWeight: "bold",
    fontSize: 16,
  },
})
