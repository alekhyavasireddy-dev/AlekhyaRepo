import React from "react"
import { View, Text, StyleSheet } from "react-native"

export default function YourDonations() {
  return (
    <View style={styles.card}>
      <Text style={styles.title}>Your Donations</Text>

      <View style={styles.row}>
        <Text style={styles.header}>Date</Text>
        <Text style={styles.header}>Asset</Text>
        <Text style={styles.header}>Amount</Text>
      </View>

      {/* Dummy Data */}
      <View style={styles.row}>
        <Text>2025-09-25</Text>
        <Text>USDT</Text>
        <Text>0.01</Text>
      </View>

      <View style={styles.row}>
        <Text>2025-09-25</Text>
        <Text>USDT</Text>
        <Text>0.01</Text>
      </View>
    </View>
  )
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#ffffff",
    padding: 20,
    borderRadius: 12,
    marginBottom: 30,
    elevation: 3
  },
  title: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 15,
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  header: {
    fontWeight: "bold",
  },
})
