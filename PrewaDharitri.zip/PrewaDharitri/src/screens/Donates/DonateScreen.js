import React from 'react'
import { ScrollView, StyleSheet } from 'react-native'
import DonateForm from './components/DonateForm'
import YourDonations from './components/YourDonations'
import AllProtocolDonations from './components/AllProtocolDonations'

export default function DonateScreen() {
  return (
    <ScrollView style={styles.container}>
      <DonateForm />
      <YourDonations />
      <AllProtocolDonations />
    </ScrollView>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    paddingHorizontal: 16,
    paddingTop: 16,
  },
})
