import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import { Ionicons, MaterialCommunityIcons, FontAwesome5 } from "@expo/vector-icons";

import HomeScreen from "../screens/HomeScreen";
import SwapScreen from "../screens/SwapScreen";
import PoolsScreen from "../screens/PoolsScreen";
import StakeScreen from "../screens/StakeScreen";
import LPStakingScreen from "../screens/LPStakingScreen";
import VestingScreen from "../screens/VestingScreen";
import DashboardScreen from "../screens/DashboardScreen";
import DonateScreen from "../screens/Donates/DonateScreen";

const Tab = createBottomTabNavigator();

export default function MainNavigator() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarStyle: {
          height: 70,
        },
        tabBarLabelStyle: {
          fontSize: 10,
          marginBottom: 6,
        },

        tabBarIcon: ({ focused }) => {
          let color = focused ? "#2563eb" : "#888";

          if (route.name === "Home") {
            return <Ionicons name="home" size={22} color={color} />;
          }
          if (route.name === "Swap") {
            return <Ionicons name="swap-horizontal" size={22} color={color} />;
          }
          if (route.name === "Pools") {
            return <MaterialCommunityIcons name="pool" size={22} color={color} />;
          }
          if (route.name === "Stake") {
            return <FontAwesome5 name="coins" size={20} color={color} />;
          }
          if (route.name === "LP Staking") {
            return <MaterialCommunityIcons name="chart-areaspline" size={22} color={color} />;
          }
          if (route.name === "Vesting") {
            return <Ionicons name="lock-closed" size={22} color={color} />;
          }
          if (route.name === "Dashboard") {
            return <Ionicons name="stats-chart" size={22} color={color} />;
          }
          if (route.name === "Donate") {
            return <Ionicons name="heart" size={22} color={color} />;
          }
        },
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Swap" component={SwapScreen} />
      <Tab.Screen name="Pools" component={PoolsScreen} />
      <Tab.Screen name="Stake" component={StakeScreen} />
      <Tab.Screen name="LP Staking" component={LPStakingScreen} />
      <Tab.Screen name="Vesting" component={VestingScreen} />
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Donate" component={DonateScreen} />
    </Tab.Navigator>
  );
}
