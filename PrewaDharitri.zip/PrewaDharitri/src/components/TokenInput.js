// TokenInput.js
import React from "react";
import { View, Text, TextInput, TouchableOpacity } from "react-native";

export default function TokenInput({
  value,
  onChange,
  tokenSymbol,
  balance = "0",
  onPercent,
  placeholder = "0.0",
  keyboardType = "decimal-pad",
}) {
  return (
    <View>
      <Text style={{ color: "#666", marginBottom: 6 }}>From</Text>
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <TextInput
          value={value}
          onChangeText={onChange}
          placeholder={placeholder}
          keyboardType={keyboardType}
          style={{
            flex: 1,
            padding: 12,
            borderWidth: 1,
            borderRadius: 8,
          }}
        />
        <View style={{ marginLeft: 10, alignItems: "flex-end" }}>
          <Text>{tokenSymbol}</Text>
          <Text style={{ fontSize: 12, color: "#777" }}>
            Bal: {Number(balance).toFixed(6)}
          </Text>
        </View>
      </View>

      <View style={{ flexDirection: "row", marginTop: 8, gap: 8 }}>
        {[{ t: "25%", v: 0.25 }, { t: "50%", v: 0.5 }, { t: "75%", v: 0.75 }, { t: "MAX", v: 1 }].map((x) => (
          <TouchableOpacity
            key={x.t}
            onPress={() => onPercent && onPercent(x.v)}
            style={{ padding: 8, borderWidth: 1, borderRadius: 8 }}
          >
            <Text>{x.t}</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}
