// SlippageSelector.js
import React from "react";
import { View, TouchableOpacity, Text } from "react-native";

export default function SlippageSelector({ value, onChange }) {
  const options = [0.5, 1, 2];
  return (
    <View style={{ marginTop: 10 }}>
      <Text>Slippage: {value}%</Text>
      <View style={{ flexDirection: "row", marginTop: 8, gap: 8 }}>
        {options.map((s) => (
          <TouchableOpacity
            key={s}
            onPress={() => onChange(s)}
            style={{
              padding: 8,
              borderRadius: 8,
              borderWidth: 1,
              backgroundColor: value === s ? "#111" : "#fff",
            }}
          >
            <Text style={{ color: value === s ? "#fff" : "#000" }}>{s}%</Text>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
}
