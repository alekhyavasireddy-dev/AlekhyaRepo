// src/components/PrimaryButton.js
import { StyleSheet, Text, TouchableOpacity } from 'react-native';
import { useTheme } from '../hooks/useTheme';

export default function PrimaryButton({ title, onPress, style }) {
  const { theme } = useTheme();
  return (
    <TouchableOpacity onPress={onPress} style={[styles.button, { backgroundColor: theme.primary }, style]}>
      <Text style={[styles.text, { color: theme.mode === 'dark' ? '#000' : '#fff' }]}>{title}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  button: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 8,
    alignItems: 'center',
  },
  text: { fontWeight: '600' },
});
