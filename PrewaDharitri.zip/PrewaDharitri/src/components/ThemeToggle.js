// src/components/ThemeToggle.js
import { Appearance, Text, TouchableOpacity, View } from 'react-native';
import { useTheme } from '../hooks/useTheme';

export default function ThemeToggle() {
  const { resolvedThemeName, setPreference } = useTheme();
  const system = Appearance.getColorScheme() ?? 'light';

  return (
    <View style={{ flexDirection: 'row', gap: 10 }}>
      <TouchableOpacity onPress={() => setPreference(null)}>
        <Text style={{ opacity: resolvedThemeName === system ? 1 : 0.6 }}>System</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setPreference('light')}>
        <Text style={{ opacity: resolvedThemeName === 'light' ? 1 : 0.6 }}>Light</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => setPreference('dark')}>
        <Text style={{ opacity: resolvedThemeName === 'dark' ? 1 : 0.6 }}>Dark</Text>
      </TouchableOpacity>
    </View>
  );
}
