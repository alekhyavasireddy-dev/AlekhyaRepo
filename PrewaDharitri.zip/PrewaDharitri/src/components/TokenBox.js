// src/components/TokenBox.js
import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { useTheme } from '../hooks/useTheme';

export default function TokenBox({ tokenAddress = '0x0440b…7fe10Bf', onAddToken }) {
  const { theme } = useTheme();
  return (
    <View style={[styles.box, { borderColor: theme.border, backgroundColor: theme.card }]}>
      <Text style={{ color: theme.text, fontWeight: '700' }}>Add pREWA to Your Wallet</Text>
      <Text style={{ color: theme.subtext, marginTop: 6 }}>{tokenAddress}</Text>

      <TouchableOpacity onPress={onAddToken} style={[styles.button, { backgroundColor: theme.primary }]}>
        <Text style={{ color: theme.mode === 'dark' ? '#000' : '#fff', textAlign: 'center' }}>Add Token</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    padding: 16,
    borderRadius: 10,
    borderWidth: 1,
    marginTop: 20,
  },
  button: {
    marginTop: 12,
    paddingVertical: 10,
    borderRadius: 6,
  },
});
