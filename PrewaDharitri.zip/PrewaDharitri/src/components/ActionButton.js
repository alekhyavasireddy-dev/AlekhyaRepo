// ActionButton.js
import React from "react";
import { TouchableOpacity, Text, ActivityIndicator } from "react-native";

export default function ActionButton({ onPress, title, loading, disabled }) {
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled || loading}
      style={{
        marginTop: 20,
        padding: 12,
        backgroundColor: disabled ? "#7fb3ff" : "#0a84ff",
        borderRadius: 8,
        alignItems: "center",
      }}
    >
      {loading ? <ActivityIndicator color="#fff" /> : <Text style={{ color: "#fff", fontWeight: "600" }}>{title}</Text>}
    </TouchableOpacity>
  );
}
