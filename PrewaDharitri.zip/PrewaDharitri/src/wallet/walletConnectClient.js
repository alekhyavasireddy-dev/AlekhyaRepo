// src/wallet/walletConnectClient.js
import SignClient from "@walletconnect/sign-client";

// Global singleton instance
let wcClient = null;

export async function getWalletConnectClient() {
  if (wcClient) return wcClient;

  wcClient = await SignClient.init({
    projectId: "e8a38ff7dacc1f10a003365e22131c5b",
    relayUrl: "wss://relay.walletconnect.com",
    metadata: {
      name: "PrewaDharitri",
      description: "Green Finance App",
      url: "https://prewa.dharitri.org",
      icons: ["https://walletconnect.com/walletconnect-logo.png"],
    },
  });

  return wcClient;
}
